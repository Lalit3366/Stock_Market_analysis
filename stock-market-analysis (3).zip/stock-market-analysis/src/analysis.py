"""
analysis.py
------------
Exploratory analysis of a multi-ticker stock price dataset: returns,
volatility, moving averages, correlation, drawdowns, and risk-adjusted
performance (Sharpe ratio).

Usage:
    python src/analysis.py

Outputs:
    - Printed summary statistics and insights to the console
    - PNG charts saved to visualizations/
"""

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# ---- Setup ---------------------------------------------------------------
sns.set_theme(style="whitegrid", palette="deep")
plt.rcParams["figure.dpi"] = 110
plt.rcParams["axes.titleweight"] = "bold"

DATA_PATH = "data/stock_prices.csv"
OUT_DIR = "visualizations"
TRADING_DAYS_PER_YEAR = 252
RISK_FREE_RATE = 0.03  # annualized, for Sharpe ratio calc

os.makedirs(OUT_DIR, exist_ok=True)


def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["date"])
    return df


def add_returns(df: pd.DataFrame) -> pd.DataFrame:
    """Add daily log returns and rolling metrics per ticker."""
    df = df.sort_values(["ticker", "date"]).copy()
    df["daily_return"] = df.groupby("ticker")["close"].transform(
        lambda s: np.log(s / s.shift(1))
    )
    df["ma_20"] = df.groupby("ticker")["close"].transform(lambda s: s.rolling(20).mean())
    df["ma_50"] = df.groupby("ticker")["close"].transform(lambda s: s.rolling(50).mean())
    df["rolling_vol_20"] = df.groupby("ticker")["daily_return"].transform(
        lambda s: s.rolling(20).std() * np.sqrt(TRADING_DAYS_PER_YEAR)
    )
    return df


def compute_performance_table(df: pd.DataFrame) -> pd.DataFrame:
    """Per-ticker annualized return, volatility, Sharpe ratio, max drawdown."""
    rows = []
    for ticker, g in df.groupby("ticker"):
        g = g.sort_values("date")
        daily_ret = g["daily_return"].dropna()

        ann_return = daily_ret.mean() * TRADING_DAYS_PER_YEAR
        ann_vol = daily_ret.std() * np.sqrt(TRADING_DAYS_PER_YEAR)
        sharpe = (ann_return - RISK_FREE_RATE) / ann_vol if ann_vol > 0 else np.nan

        cum_return = g["close"].iloc[-1] / g["close"].iloc[0] - 1

        # Max drawdown
        cum_prices = g["close"].values
        running_max = np.maximum.accumulate(cum_prices)
        drawdown = (cum_prices - running_max) / running_max
        max_drawdown = drawdown.min()

        rows.append({
            "ticker": ticker,
            "sector": g["sector"].iloc[0],
            "total_return_pct": round(cum_return * 100, 2),
            "annualized_return_pct": round(ann_return * 100, 2),
            "annualized_volatility_pct": round(ann_vol * 100, 2),
            "sharpe_ratio": round(sharpe, 2),
            "max_drawdown_pct": round(max_drawdown * 100, 2),
        })

    perf = pd.DataFrame(rows).sort_values("sharpe_ratio", ascending=False).reset_index(drop=True)
    return perf


def print_overview(df: pd.DataFrame, perf: pd.DataFrame) -> None:
    print("=" * 70)
    print("DATASET OVERVIEW")
    print("=" * 70)
    print(f"Tickers: {df['ticker'].nunique()} | Sectors: {df['sector'].nunique()}")
    print(f"Date range: {df['date'].min().date()} -> {df['date'].max().date()}")
    print(f"Total rows: {len(df):,}")

    print("\nPerformance summary (sorted by Sharpe ratio):")
    print(perf.to_string(index=False))

    print("\nBest performer (total return): "
          f"{perf.sort_values('total_return_pct', ascending=False).iloc[0]['ticker']}")
    print("Worst performer (total return): "
          f"{perf.sort_values('total_return_pct', ascending=True).iloc[0]['ticker']}")
    print("Lowest volatility: "
          f"{perf.sort_values('annualized_volatility_pct', ascending=True).iloc[0]['ticker']}")


def plot_price_trends(df: pd.DataFrame) -> None:
    plt.figure(figsize=(12, 6))
    for ticker, g in df.groupby("ticker"):
        plt.plot(g["date"], g["close"], label=ticker, linewidth=1.3)
    plt.title("Closing Price Trends by Ticker")
    plt.xlabel("Date")
    plt.ylabel("Close Price ($)")
    plt.legend(loc="upper left", ncol=2, fontsize=8)
    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/01_price_trends.png")
    plt.close()


def plot_moving_average_example(df: pd.DataFrame, ticker: str = "TCHX") -> None:
    g = df[df["ticker"] == ticker].sort_values("date")

    plt.figure(figsize=(12, 5.5))
    plt.plot(g["date"], g["close"], label="Close", linewidth=1, alpha=0.7)
    plt.plot(g["date"], g["ma_20"], label="20-day MA", linewidth=1.6)
    plt.plot(g["date"], g["ma_50"], label="50-day MA", linewidth=1.6)
    plt.title(f"{ticker}: Price with 20/50-Day Moving Averages")
    plt.xlabel("Date")
    plt.ylabel("Price ($)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/02_moving_averages_{ticker}.png")
    plt.close()


def plot_returns_correlation(df: pd.DataFrame) -> None:
    pivot = df.pivot(index="date", columns="ticker", values="daily_return")
    corr = pivot.corr()

    plt.figure(figsize=(9, 7.5))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0, square=True, linewidths=0.5)
    plt.title("Correlation of Daily Returns Across Tickers")
    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/03_returns_correlation.png")
    plt.close()


def plot_volatility_comparison(df: pd.DataFrame) -> None:
    plt.figure(figsize=(11, 5.5))
    for ticker, g in df.groupby("ticker"):
        plt.plot(g["date"], g["rolling_vol_20"], label=ticker, linewidth=1.1)
    plt.title("20-Day Rolling Annualized Volatility by Ticker")
    plt.xlabel("Date")
    plt.ylabel("Annualized Volatility")
    plt.legend(loc="upper left", ncol=2, fontsize=8)
    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/04_rolling_volatility.png")
    plt.close()


def plot_sector_performance(perf: pd.DataFrame) -> None:
    sector_perf = perf.groupby("sector")["total_return_pct"].mean().sort_values(ascending=False)

    plt.figure(figsize=(9, 5))
    sns.barplot(x=sector_perf.values, y=sector_perf.index, hue=sector_perf.index,
                palette="mako", legend=False)
    plt.title("Average Total Return by Sector")
    plt.xlabel("Total Return (%)")
    plt.ylabel("Sector")
    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/05_sector_performance.png")
    plt.close()


def plot_risk_return_scatter(perf: pd.DataFrame) -> None:
    plt.figure(figsize=(9, 6.5))
    sns.scatterplot(
        data=perf, x="annualized_volatility_pct", y="annualized_return_pct",
        hue="sector", s=140, edgecolor="black"
    )
    for _, row in perf.iterrows():
        plt.text(row["annualized_volatility_pct"] + 0.3, row["annualized_return_pct"],
                  row["ticker"], fontsize=8)
    plt.title("Risk vs. Return by Ticker")
    plt.xlabel("Annualized Volatility (%)")
    plt.ylabel("Annualized Return (%)")
    plt.axhline(0, color="grey", linewidth=0.8, linestyle="--")
    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/06_risk_return_scatter.png")
    plt.close()


def plot_drawdown_example(df: pd.DataFrame, ticker: str = "TCHY") -> None:
    g = df[df["ticker"] == ticker].sort_values("date").copy()
    running_max = g["close"].cummax()
    g["drawdown_pct"] = (g["close"] - running_max) / running_max * 100

    plt.figure(figsize=(12, 5))
    plt.fill_between(g["date"], g["drawdown_pct"], 0, color="crimson", alpha=0.4)
    plt.plot(g["date"], g["drawdown_pct"], color="crimson", linewidth=1)
    plt.title(f"{ticker}: Drawdown from Running Peak")
    plt.xlabel("Date")
    plt.ylabel("Drawdown (%)")
    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/07_drawdown_{ticker}.png")
    plt.close()


def main():
    df = load_data(DATA_PATH)
    df = add_returns(df)
    perf = compute_performance_table(df)

    print_overview(df, perf)

    plot_price_trends(df)
    plot_moving_average_example(df, ticker="TCHX")
    plot_returns_correlation(df)
    plot_volatility_comparison(df)
    plot_sector_performance(perf)
    plot_risk_return_scatter(perf)
    plot_drawdown_example(df, ticker="TCHY")

    print(f"\nAll charts saved to '{OUT_DIR}/'")


if __name__ == "__main__":
    main()
