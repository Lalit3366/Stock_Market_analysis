"""
generate_data.py
-----------------
Generates a synthetic multi-ticker daily stock price dataset using
Geometric Brownian Motion (GBM), for use in the stock market analysis project.

Run this once to (re)create data/stock_prices.csv.
"""

import numpy as np
import pandas as pd

np.random.seed(7)

# ---- Configuration -----------------------------------------------------
START_DATE = "2021-01-01"
END_DATE = "2024-12-31"

# ticker: (sector, starting_price, annual_drift, annual_volatility)
TICKERS = {
    "TCHX": ("Technology",  120.0, 0.18, 0.35),
    "TCHY": ("Technology",   80.0, 0.22, 0.40),
    "FINB": ("Financials",   55.0, 0.08, 0.22),
    "FINC": ("Financials",   40.0, 0.06, 0.20),
    "HLTH": ("Healthcare",   95.0, 0.10, 0.18),
    "HLTZ": ("Healthcare",   65.0, 0.12, 0.24),
    "ENRG": ("Energy",       35.0, 0.05, 0.30),
    "CONS": ("Consumer",     70.0, 0.09, 0.16),
    "INDL": ("Industrials",  60.0, 0.07, 0.19),
    "UTIL": ("Utilities",    45.0, 0.04, 0.12),
}

trading_days = pd.bdate_range(START_DATE, END_DATE)  # business days only
n_days = len(trading_days)

records = []

for ticker, (sector, start_price, mu, sigma) in TICKERS.items():
    dt = 1 / 252  # one trading day as a fraction of a trading year

    # Geometric Brownian Motion: dS = mu*S*dt + sigma*S*dW
    daily_shocks = np.random.normal(
        loc=(mu - 0.5 * sigma**2) * dt,
        scale=sigma * np.sqrt(dt),
        size=n_days,
    )
    log_prices = np.log(start_price) + np.cumsum(daily_shocks)
    close_prices = np.exp(log_prices)

    # Derive open/high/low from close with small intraday noise
    intraday_noise = np.random.uniform(0.995, 1.005, size=n_days)
    open_prices = close_prices * intraday_noise
    daily_range = close_prices * np.random.uniform(0.005, 0.025, size=n_days)
    high_prices = np.maximum(open_prices, close_prices) + daily_range / 2
    low_prices = np.minimum(open_prices, close_prices) - daily_range / 2

    # Volume: base level with random spikes correlated to |return|
    returns = np.diff(np.log(close_prices), prepend=np.log(start_price))
    base_volume = np.random.randint(2_000_000, 8_000_000)
    volume = (base_volume * (1 + 8 * np.abs(returns)) * np.random.uniform(0.8, 1.2, n_days)).astype(int)

    df_ticker = pd.DataFrame({
        "date": trading_days,
        "ticker": ticker,
        "sector": sector,
        "open": open_prices.round(2),
        "high": high_prices.round(2),
        "low": low_prices.round(2),
        "close": close_prices.round(2),
        "volume": volume,
    })
    records.append(df_ticker)

df = pd.concat(records, ignore_index=True)
df = df.sort_values(["ticker", "date"]).reset_index(drop=True)

output_path = "data/stock_prices.csv"
df.to_csv(output_path, index=False)
print(f"Generated {len(df):,} rows across {len(TICKERS)} tickers -> {output_path}")
print(df.head())
