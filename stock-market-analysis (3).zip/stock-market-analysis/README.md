# 📈 Stock Market Data Analysis

An exploratory data analysis (EDA) project on multi-ticker daily stock price data, built with **NumPy**, **Pandas**, **Matplotlib**, and **Seaborn**. Covers returns, volatility, moving averages, correlation, drawdowns, and risk-adjusted performance — the core toolkit of quantitative/financial data analysis.

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![Pandas](https://img.shields.io/badge/Pandas-2.x-150458)
![NumPy](https://img.shields.io/badge/NumPy-1.26-013243)
![License](https://img.shields.io/badge/License-MIT-green)

## 📊 Project Overview

This project analyzes 4 years (2021–2024) of simulated daily price data for 10 tickers across 7 sectors (Technology, Financials, Healthcare, Energy, Consumer, Industrials, Utilities). It answers questions like:

- How have prices trended over time across sectors?
- Which stocks offer the best risk-adjusted returns (Sharpe ratio)?
- How correlated are different stocks' daily returns — where are the diversification opportunities?
- How volatile is each stock, and how does volatility change over time?
- What's the worst peak-to-trough decline (max drawdown) each stock has experienced?

## 🗂️ Project Structure

```
stock-market-analysis/
├── data/
│   └── stock_prices.csv         # Synthetic multi-ticker OHLCV dataset
├── src/
│   ├── generate_data.py         # Generates synthetic prices via Geometric Brownian Motion
│   └── analysis.py              # Main EDA + visualization script
├── visualizations/               # Output charts (PNG)
├── notebooks/
│   └── exploratory_analysis.ipynb  # Interactive notebook version
├── requirements.txt
├── LICENSE
└── README.md
```

## ⚙️ Setup

```bash
# Clone the repository
git clone https://github.com/<your-username>/stock-market-analysis.git
cd stock-market-analysis

# Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate      # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## 🚀 Usage

**1. Generate the dataset** (already included, but you can regenerate it):

```bash
python src/generate_data.py
```

**2. Run the full analysis:**

```bash
python src/analysis.py
```

This prints a per-ticker performance table (return, volatility, Sharpe ratio, max drawdown) to the console and saves seven charts to `visualizations/`.

Alternatively, open `notebooks/exploratory_analysis.ipynb` in Jupyter for an interactive walkthrough.

## 📈 Key Visualizations

| Chart | Description |
|---|---|
| `01_price_trends.png` | Closing price trends for all 10 tickers |
| `02_moving_averages_TCHX.png` | Price with 20-day and 50-day moving averages (example ticker) |
| `03_returns_correlation.png` | Correlation matrix of daily returns across tickers |
| `04_rolling_volatility.png` | 20-day rolling annualized volatility by ticker |
| `05_sector_performance.png` | Average total return by sector |
| `06_risk_return_scatter.png` | Risk (volatility) vs. return, colored by sector |
| `07_drawdown_TCHY.png` | Peak-to-trough drawdown over time (example ticker) |

### Sample Output

![Price Trends](visualizations/01_price_trends.png)
![Returns Correlation](visualizations/03_returns_correlation.png)
![Risk vs Return](visualizations/06_risk_return_scatter.png)

## 🔍 Key Findings

- **Healthcare (HLTZ)** and **Financials (FINC)** delivered the strongest risk-adjusted returns, posting the highest Sharpe ratios in the dataset.
- **Energy (ENRG)** was the weakest performer, with a steep total-return decline and the largest maximum drawdown.
- **Technology** tickers exhibit the highest volatility, consistent with the sector's typically higher-risk profile.
- **Utilities (UTIL)** shows the lowest volatility, reflecting its defensive, low-beta character.
- Return correlations vary meaningfully across sectors, highlighting real diversification benefits from holding stocks across different sectors rather than within just one.

## 🧮 Methodology Notes

- **Daily returns** are computed as log returns: `ln(close_t / close_t-1)`.
- **Annualized return/volatility** scale daily statistics by `√252` (volatility) or `×252` (mean return), the standard trading-days-per-year convention.
- **Sharpe ratio** = `(annualized return − risk-free rate) / annualized volatility`, using a 3% annual risk-free rate assumption.
- **Max drawdown** is the largest observed decline from a running peak to a subsequent trough, expressed as a percentage.

## 🧰 Tech Stack

- **NumPy** – Geometric Brownian Motion price simulation, vectorized return/drawdown calculations
- **Pandas** – time-series handling, rolling windows, groupby aggregations
- **Matplotlib** – multi-series line charts, drawdown area plots
- **Seaborn** – correlation heatmaps, scatter plots, categorical bar charts

## 📄 Data Notes

The dataset (`data/stock_prices.csv`) is **synthetically generated** (see `src/generate_data.py`) using Geometric Brownian Motion with sector-specific drift and volatility parameters, so the relative behavior of sectors (e.g., Tech being more volatile than Utilities) is realistic even though the exact price paths are simulated, not real market data.

## 📝 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

## 🤝 Contributing

Feel free to fork this repo, open issues, or submit pull requests with additional analyses (e.g., portfolio optimization, backtesting a trading strategy, factor analysis).
